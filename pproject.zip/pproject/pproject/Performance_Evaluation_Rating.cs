﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class Performance_Evaluation_Rating : Form
    {
        public Performance_Evaluation_Rating()
        {
            InitializeComponent();
            Fillcombo();
            Fillcombo1();

        }




        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {



        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Employee";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string id = myreader.GetString(2);
                    comboBox1.Items.Add(id);


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        
        void Fillcombo1()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Performance_Evaluation";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    
                    string id = myreader.GetString(1);
                    comboBox2.Items.Add(id);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                string query = "Select Employee_Id,Rating From Employee Where emp_fname='" + comboBox1.SelectedItem.ToString() + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    textBox3.Text = dr["Rating"].ToString();//Value From Column we want to show on textbox
                    textBox1.Text = dr["Employee_Id"].ToString();
                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        SqlConnection con;
        SqlDataAdapter sda;

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                sda = new SqlDataAdapter("SELECT Responsibility1_Rating,Responsibility2_Rating,Responsibility3_Rating,Responsibility4_Rating,Responsibility5_Rating,Behavior_Rating FROM Performance_Evaluation  WHERE Employee_Id='"+textBox1.Text+"' AND Performance_Evaluation_No='" + comboBox2.SelectedItem.ToString() + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                groupBox2.Text = "EMPLOYEE RESPONSIBILITY RATING";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Performance_Evaluation_Rating_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
                   {int sum = 0;
                   float result;
                   float result1 = 0;

                    for (int i = 0; i < dataGridView1.Rows.Count; ++i)
                {
                    sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value) + Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value)+Convert.ToInt32(dataGridView1.Rows[i].Cells[2].Value)+Convert.ToInt32(dataGridView1.Rows[i].Cells[3].Value)+Convert.ToInt32(dataGridView1.Rows[i].Cells[4].Value)+Convert.ToInt32(dataGridView1.Rows[i].Cells[5].Value);
                     result = sum / 5;
                     result1 = result;
                     if (result1 <= 9)
                     {
                         result1 = result;
                     }
                     else
                     {
                         result1 = 10;
                     }
                           
                     textBox2.Text = result1.ToString();
                }
                   
                }

               catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);

                   }
                            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 val1 = Convert.ToInt32(textBox2.Text);
                Int32 val2 = Convert.ToInt32(textBox3.Text);
                Int32 val3 = val1 * val2;
                label5.Text = val3.ToString();
                SqlConnection con;
                SqlDataAdapter da = new SqlDataAdapter();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                da.UpdateCommand = new SqlCommand("UPDATE Employee SET Rating = '" + label5.Text + "'  WHERE Employee_Id='" + textBox1.Text + "' ", con);
                da.UpdateCommand.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
                               
        }
        
    }

}
