﻿namespace pproject
{
    partial class New_Project
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.p_id = new System.Windows.Forms.TextBox();
            this.p_title = new System.Windows.Forms.TextBox();
            this.p_manager = new System.Windows.Forms.TextBox();
            this.rich_detail = new System.Windows.Forms.RichTextBox();
            this.employeeskillBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.projectDataSet = new pproject.ProjectDataSet();
            this.employeeskillTableAdapter = new pproject.ProjectDataSetTableAdapters.employeeskillTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.com_status = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtp_complete = new System.Windows.Forms.DateTimePicker();
            this.dtp_start = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.employeeskillBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Project Title";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(402, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Manager Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(38, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Project Detail";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Project ID";
            // 
            // p_id
            // 
            this.p_id.Location = new System.Drawing.Point(146, 29);
            this.p_id.Name = "p_id";
            this.p_id.Size = new System.Drawing.Size(221, 22);
            this.p_id.TabIndex = 0;
            this.p_id.TextChanged += new System.EventHandler(this.p_id_TextChanged);
            // 
            // p_title
            // 
            this.p_title.Location = new System.Drawing.Point(146, 60);
            this.p_title.Name = "p_title";
            this.p_title.Size = new System.Drawing.Size(221, 22);
            this.p_title.TabIndex = 2;
            // 
            // p_manager
            // 
            this.p_manager.Location = new System.Drawing.Point(520, 32);
            this.p_manager.Name = "p_manager";
            this.p_manager.Size = new System.Drawing.Size(197, 22);
            this.p_manager.TabIndex = 1;
            // 
            // rich_detail
            // 
            this.rich_detail.Location = new System.Drawing.Point(146, 122);
            this.rich_detail.Name = "rich_detail";
            this.rich_detail.Size = new System.Drawing.Size(221, 59);
            this.rich_detail.TabIndex = 6;
            this.rich_detail.Text = "";
            // 
            // employeeskillBindingSource
            // 
            this.employeeskillBindingSource.DataMember = "employeeskill";
            this.employeeskillBindingSource.DataSource = this.projectDataSet;
            // 
            // projectDataSet
            // 
            this.projectDataSet.DataSetName = "ProjectDataSet";
            this.projectDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeskillTableAdapter
            // 
            this.employeeskillTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.groupBox1.Controls.Add(this.com_status);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.dtp_complete);
            this.groupBox1.Controls.Add(this.dtp_start);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.p_title);
            this.groupBox1.Controls.Add(this.rich_detail);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.p_manager);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.p_id);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(7, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(792, 227);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Add Project";
            // 
            // com_status
            // 
            this.com_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.com_status.FormattingEnabled = true;
            this.com_status.Items.AddRange(new object[] {
            "Started",
            "Pending"});
            this.com_status.Location = new System.Drawing.Point(521, 72);
            this.com_status.Name = "com_status";
            this.com_status.Size = new System.Drawing.Size(197, 24);
            this.com_status.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(402, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Status";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // dtp_complete
            // 
            this.dtp_complete.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_complete.Location = new System.Drawing.Point(520, 114);
            this.dtp_complete.Name = "dtp_complete";
            this.dtp_complete.Size = new System.Drawing.Size(198, 22);
            this.dtp_complete.TabIndex = 5;
            // 
            // dtp_start
            // 
            this.dtp_start.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_start.Location = new System.Drawing.Point(146, 92);
            this.dtp_start.Name = "dtp_start";
            this.dtp_start.Size = new System.Drawing.Size(221, 22);
            this.dtp_start.TabIndex = 4;
            this.dtp_start.Value = new System.DateTime(2017, 3, 20, 17, 45, 41, 0);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(402, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Completion Date";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(42, 98);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 16);
            this.label6.TabIndex = 10;
            this.label6.Text = "Start Date";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(282, 186);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(85, 35);
            this.button1.TabIndex = 7;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // New_Project
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(797, 228);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "New_Project";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New_Project";
            this.Load += new System.EventHandler(this.New_Project_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeeskillBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.projectDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox p_id;
        private System.Windows.Forms.TextBox p_title;
        private System.Windows.Forms.TextBox p_manager;
        private System.Windows.Forms.RichTextBox rich_detail;
        private ProjectDataSet projectDataSet;
        private System.Windows.Forms.BindingSource employeeskillBindingSource;
        private ProjectDataSetTableAdapters.employeeskillTableAdapter employeeskillTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dtp_complete;
        private System.Windows.Forms.DateTimePicker dtp_start;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox com_status;
        private System.Windows.Forms.Label label7;
    }
}