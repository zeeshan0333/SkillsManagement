﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;


namespace pproject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

       
        private void label3_Click(object sender, EventArgs e)
        {

        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Enter)
            {
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            SqlDataAdapter sda = new SqlDataAdapter("Select username From login1 where username='"+textBox1.Text+"'and password='"+textBox2.Text+"'",con);
            DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);
            if(dt.Rows.Count==1)
            {
                this.Hide();
                if (dt.Rows[0][0].ToString() == "employee")
                {
                    Form2 f2 = new Form2();
                    f2.Show();
                }
                
                else if (dt.Rows[0][0].ToString() == "manager")
                {
                    manager m = new manager();
                    m.Show();
                }
                else  if (dt.Rows[0][0].ToString() == "admin")
                {
                    admin n = new admin();
                    n.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password");
                }

                  if (textBox2.Text == "")
            {
                errorProvider1.SetError(textBox2, "enter correct password");
            
            }
            
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_Validating_1(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(textBox2.Text))
            {
                errorProvider1.SetError(textBox2, "Password required!");
            }
            else if (!Regex.IsMatch(textBox2.Text, @"[A-Za-z][A-Za-z0-9]{2,7}"))
            {
                errorProvider1.SetError(textBox2, "Password invalid!");
            }
            else
            {
                errorProvider1.SetError(textBox2, null);
            }
        }
                      
        }
        
    }

