﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace pproject
{
    public partial class admin : Form
    {
        public admin()
        {
            InitializeComponent();
        }
        SqlConnection cs;
        SqlCommand cmd;
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }
        

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        string query;
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                cs.Open();
                query = "insert into Training values('" + txt_training.Text + "','" + txt_training_name.Text + "', '" + com_duration.SelectedItem.ToString() + "','" + rich_description1.Text + "')";
                cmd = new SqlCommand(query, cs);
                cmd.ExecuteNonQuery();
                cs.Close();
                MessageBox.Show("Training Record Inserted sucessfully");
            }
            catch(Exception ec)
            {
                MessageBox.Show(ec.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                cs.Open();
                query = "insert into Skill values('" + txt_id.Text + "','" + txt_name.Text + "','" + rich_description.Text + "')";
                cmd = new SqlCommand(query, cs);
                cmd.ExecuteNonQuery();
                cs.Close();
                MessageBox.Show("Skill Added Sucessfully");
            }
            catch(Exception ec)
            {
                MessageBox.Show(ec.Message);  
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form1 f1 = new Form1();
            f1.Show();
        }
    }
}
