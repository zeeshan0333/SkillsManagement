﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class UpdateSkill1 : Form
    {
        public UpdateSkill1()
        {
            InitializeComponent();
            Fillcombo();
                      
        }
        SqlConnection con;
        SqlCommand cmd;
           
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridView1.Columns[e.ColumnIndex].HeaderText == "Rate Skill")
                {
                    Update11 export = new Update11();

                    export.emp_id.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[1].Value.ToString();

                    export.skill_id.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[3].Value.ToString();

                    export.success_factor.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[6].Value.ToString();


                    export.Show();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void UpdateSkill1_Load(object sender, EventArgs e)
        {
           
        }
        void Fillcombo()
        {
            con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Employee";
            cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int id = myreader.GetInt32(0);
                    comboBox1.Items.Add(id);
                   

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
           
        }

        private void comboBox1_SelectedIndexChanged_2(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                SqlDataAdapter adapter = new SqlDataAdapter();
                con.Open();
                string query;
                SqlCommand SqlCommand;      
                query = "SELECT * From Employee_Task where Employee_Id='"+comboBox1.SelectedItem.ToString()+"'";
                SqlCommand = new SqlCommand(query, con);
                adapter.SelectCommand = new SqlCommand(query, con);             
                SqlCommand.ExecuteNonQuery();              
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
