﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace pproject
{
    public partial class ViewProject : Form
    {
        public ViewProject()
        {
            InitializeComponent();
        }
        SqlConnection con;
        SqlDataAdapter sda;
        SqlCommand cmd;
        
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }
       
        protected void dataGridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
                    

        }

        private void ViewProject_Load(object sender, EventArgs e)
        {
            
            con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            cmd = new SqlCommand("SELECT * FROM Project", con);
            cmd.CommandType = CommandType.Text;
            sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
                    
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)// created column index (delete button)
                {

                    SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");

                    string query = "Delete  From  Project where p_id='" + dataGridView1.Rows[e.RowIndex].Cells[1].Value + " '";
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("successfully Deleted", "user information");

                    dataGridView1.Rows.Remove(dataGridView1.Rows[e.RowIndex]);
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

       
    }
}
