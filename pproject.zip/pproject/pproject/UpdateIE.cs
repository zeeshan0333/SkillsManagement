﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class UpdateIE : Form
    {
        public UpdateIE()
        {
            InitializeComponent();
            Fillcombo();
        }


        void Fillcombo()
        {
           SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Employee";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int id = myreader.GetInt32(0);
                    comboBox1.Items.Add(id);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Int32 val1 = Convert.ToInt32(p_rating1.Text);
                Int32 val2 = Convert.ToInt32(comboBox2.SelectedItem.ToString());
                Int32 val3 = val1 * val2;
                int result;
                if (val3 <= 9)
                {
                    result = val3;
                }
                else
                {
                    result = 10;
                }
                label5.Text = result.ToString();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                string query = ("UPDATE Employee SET Rating= '" + label5.Text + "'  WHERE Employee_Id='" + comboBox1.SelectedItem.ToString() + "'");
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                con.Close();

            }
            catch (Exception ec)
            {
                MessageBox.Show(ec.Message);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Select Rating From Employee Where  Employee_Id='" + comboBox1.Text + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    string Ts = (string)dr["Rating"].ToString();
                    p_rating1.Text = Ts;//Value From Column we want to show on textbox

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void p_rating1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
