﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class AddSkill : Form
    {
        Dictionary<string, int> integers = new Dictionary<string, int>();
        string query;
        SqlConnection con;
        SqlCommand cmd;

        public AddSkill()
        {
            integers.Add("Specialized", 5);
            integers.Add("Minor 1", 4);
            integers.Add("Minor 2", 3);
            integers.Add("Minor 3", 2);
            integers.Add("Minor 4", 1);
            InitializeComponent();
            Fillcombo();
            
            
        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Skill";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string id = myreader.GetString(0);
                    com_skill_id.Items.Add(id);                  
                   
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                query = "insert into Employee_Skill(Employee_Id,Skill_Id,Skill_Level,Skill_Duration) values('" + textBox1.Text + "','" + com_skill_id.SelectedItem.ToString() + "','" + integers[(string)comboBox1.SelectedItem] + "', '" + com_years.SelectedItem.ToString() + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Skill Record Inserted sucessfully");
            }
            catch(Exception ec)
            {
                MessageBox.Show(ec.Message);  
            }
            

        }

        private void AddSkill_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        

        private void com_skill_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
