﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Source code Started
using System.Data.SqlClient;

namespace pproject
{
    public partial class manager : Form
        
    {
        Dictionary<string, int> integers = new Dictionary<string, int>();
        SqlConnection con;
        SqlDataAdapter sda;
        SqlCommand cmd;
       
        public manager()
        {
            InitializeComponent();
            integers.Add("Specialized", 5);
            integers.Add("Minor 1", 4);
            integers.Add("Minor 2", 3);
            integers.Add("Minor 3", 2);
            integers.Add("Minor 4", 1);
            Fillcombo();
            Fillcombo1();
            Fillcombo2();
        }

               private void nEWToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

               private void vIEWToolStripMenuItem_Click(object sender, EventArgs e)
               {
                  
               }
                   
               private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
               {
                   
        
               }

               private void manager_Load(object sender, EventArgs e)
               {

                  
                   con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                   con.Open();               
                   sda = new SqlDataAdapter("SELECT *From Employee_Task", con);
                   DataTable dt1 = new DataTable();
                   sda.Fill(dt1);
                   dataGridView2.DataSource = dt1;
                   con.Close();
                   
               }

               private void groupBox1_Enter(object sender, EventArgs e)
               {

               }
               void Fillcombo()
               {
                   con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                   string query = "select * from Employee";
                   cmd = new SqlCommand(query, con);
                   SqlDataReader myreader;
                   try
                   {
                       con.Open();
                       myreader = cmd.ExecuteReader();
                       while (myreader.Read())
                       {
                           int id = myreader.GetInt32(0);
                           com_id.Items.Add(id);
                        int tid = myreader.GetInt32(0);
                           comboBox1.Items.Add(tid);
                           int idd = myreader.GetInt32(0);
                           comboBox2.Items.Add(idd);
                           
                       }

                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);
                   }


               }
               void Fillcombo1()
               {
                   con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                   string query = "select * from Tasks ";
                   cmd = new SqlCommand(query, con);
                   SqlDataReader myreader;
                   try
                   {
                       con.Open();
                       myreader = cmd.ExecuteReader();
                       while (myreader.Read())
                       {
                           int pid = myreader.GetInt32(0);
                           com_ptitle.Items.Add(pid);
                           string tid = myreader.GetString(2);
                           com_tid.Items.Add(tid);                      

                       }

                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);
                   }


               }
               private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
               {
                  
               }
               string qry;
               void Fillcombo2()
               {
                   SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                   string query = "select * from Skill";
                   SqlCommand cmd = new SqlCommand(query, con);
                   SqlDataReader myreader;
                   try
                   {
                       con.Open();
                       myreader = cmd.ExecuteReader();
                       while (myreader.Read())
                       {
                           string id = myreader.GetString(0);
                           com_Skill.Items.Add(id);


                       }

                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);
                   }


               }

               private void button1_Click(object sender, EventArgs e)
               {
                   try
                   {
                       con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                       con.Open();
                       qry = "insert into Employee_Task(Employee_Id,Task_Id,Skill_Id,p_id,Task_Detail) values('" + com_id.SelectedItem.ToString() + "','" + com_tid.SelectedItem.ToString() + "','" + com_Skill.SelectedItem.ToString() + "','" + com_ptitle.SelectedItem.ToString() + "','" + rich_detail.Text + "')";
                       cmd = new SqlCommand(qry, con);
                       cmd.ExecuteNonQuery();
                       con.Close();
                       MessageBox.Show("Task Assigned Sucessfully");
                       sda = new SqlDataAdapter("SELECT *From Employee_Task", con);
                       DataTable dt = new DataTable();
                       sda.Fill(dt);
                       dataGridView2.DataSource = dt;
                       com_id.SelectedIndex = -1;
                       com_tid.SelectedIndex = -1;
                       com_Skill.SelectedIndex = -1;
                       com_ptitle.SelectedIndex = -1;
                       rich_detail.Text = "";


                       
                   }
                   catch(Exception ex)
                   {
                       MessageBox.Show(ex.Message);

                   }
               }

               private void uPDATESKILLToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   
               }

               private void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
               {

               }

               private void vIEWSKILLSToolStripMenuItem_Click(object sender, EventArgs e)
               {
                  
               }

               private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
               {
                  
               }

               private void button2_Click(object sender, EventArgs e)
               {
                   SqlConnection con;
                   SqlDataAdapter da = new SqlDataAdapter();                  
                   con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                   con.Open();
                   da.UpdateCommand = new SqlCommand("UPDATE Employee_Task SET  p_id=@p_id ,Task_Detail=@Task_Detail WHERE Employee_Id='" + com_id.SelectedItem.ToString() + "'", con);
                   
                   da.UpdateCommand.Parameters.Add("@p_id", SqlDbType.Int).Value = com_ptitle.SelectedItem;
                   da.UpdateCommand.Parameters.Add("@Task_Detail", SqlDbType.VarChar).Value = rich_detail.Text;                  
                   da.UpdateCommand.ExecuteNonQuery();
                   MessageBox.Show("Updated Successfully");
                   con.Close();
                   com_id.SelectedIndex = -1;
                   com_tid.SelectedIndex = -1;
                   com_Skill.SelectedIndex = -1;
                   com_ptitle.SelectedIndex = -1;
                   rich_detail.Text = "";
               }
               //
               private void button3_Click(object sender, EventArgs e)
               {
                   try
                   {
                       con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                       sda = new SqlDataAdapter("SELECT Subjects,Educational_Level FROM Employee_Education  WHERE Employee_Id='" + comboBox1.SelectedItem.ToString() + "'", con);
                       DataTable dt = new DataTable();
                       sda.Fill(dt);
                       dataGridView1.DataSource = dt;
                       con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                       sda = new SqlDataAdapter("SELECT Field,Experience_Level FROM Employee_Experience  WHERE Employee_Id='" + comboBox1.SelectedItem.ToString() + "'", con);
                       DataTable dt2 = new DataTable();
                       sda.Fill(dt2);
                       dataGridView4.DataSource = dt2;
                       groupBox4.Text = "EMPLOYEE EDUCATIONAL RECORD";
                       groupBox3.Text = "EMPLOYEE EXPERIENCE RECORD";
                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);
                   }
               }


              
               private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
               {
                   try
                   {
                       DataTable dt;
                       SqlDataAdapter da = new SqlDataAdapter(@"SELECT Employee_Id,Task_Id,Skill_Id,p_id,Task_Detail FROM Employee_Task where Employee_Id='"+comboBox2.SelectedItem.ToString()+"'", con);
                       dt = new DataTable();
                       da.Fill(dt);
                       dataGridView3.DataSource = dt;
                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);

                   }
               }

               private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
               {
                   
                 if(dataGridView3.Columns[e.ColumnIndex].HeaderText=="Rate")
                   {
              Rating export = new Rating();
              export.textBox1.Text = dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells[1].Value.ToString();

               export.textBox2.Text =dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells[2].Value.ToString();              

               export.textBox4.Text = dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells[3].Value.ToString();

               export.textBox3.Text = dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells[4].Value.ToString();

               export.richTextBox1.Text =dataGridView3.Rows[dataGridView3.CurrentRow.Index].Cells[5].Value.ToString();

               export.Show();               
               
                    }
      
                }

               private void basedOnEmployeePerformannceToolStripMenuItem_Click(object sender, EventArgs e)
               {
                  
               }

               private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
               {

               }

               private void groupBox2_Enter(object sender, EventArgs e)
               {

               }

               private void eDITToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   ViewTask vt = new ViewTask();
                   vt.Show();
               }

               private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
               {

               }

               private void dataGridView2_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
               {
                   try
                   {
                       if (e.ColumnIndex == 0)// created column index (delete button)
                       {

                           SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");

                           string query = "Delete  From  Employee_Task where Task_Id='" + dataGridView2.Rows[e.RowIndex].Cells[2].Value + " '";
                           cmd = new SqlCommand(query, con);
                           con.Open();
                           cmd.CommandType = CommandType.Text;
                           cmd.ExecuteNonQuery();
                           MessageBox.Show("successfully Deleted", "user information");

                           dataGridView2.Rows.Remove(dataGridView2.Rows[e.RowIndex]);
                           con.Close();
                       }
                   }
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);
                   }
               }

               private void basedOnPerformanceEvaluationToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   Performance_Evaluation_Rating pr = new Performance_Evaluation_Rating();
                   pr.Show();
               }

               private void aSSIGNTASKToolStripMenuItem_Click(object sender, EventArgs e)
               {

               }

               private void button4_Click(object sender, EventArgs e)
               {
                   try
                   {
                       int sum = 0;
                       
                       float result = 0;
                       float result1 = 0;
                       for (int i = 0; i < dataGridView1.Rows.Count; ++i)

                       {
                           for (int j = 0; j < dataGridView4.Rows.Count; ++j)
                            sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value) + Convert.ToInt32(dataGridView4.Rows[j].Cells[1].Value);
                           result = sum / 2;
                           result1 = result;                 
                                                     
                        SqlConnection con;
                               SqlDataAdapter da = new SqlDataAdapter();
                               con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                               con.Open();
                               da.UpdateCommand = new SqlCommand("UPDATE Employee SET Rating = '" + label8.Text + "'  WHERE Employee_Id='" + comboBox1.SelectedItem.ToString() + "' ", con);
                               da.UpdateCommand.ExecuteNonQuery();                               
                               con.Close();

                               if (result1 <= 9)
                               {
                                   result1 =result;
                                   label8.Text = result1.ToString();

                               }
                               else
                               {
                                   result1 = 10;
                                   label8.Text = result1.ToString();
                               }


                              

                               if (result1 == 1 || result1 < 5)
                               {
                                   label11.Text = "Beginner";
                               }
                               else if (result1 == 6 || result1 < 10)
                               {
                                   label11.Text = "Intermediate";
                               }
                               else if (result1 == 10)
                               {
                                   label11.Text = "Expert";
                               }
                               else
                               {
                                   label11.Text = "Not Specified";
                               }

                               label9.Text = comboBox1.SelectedItem.ToString();
                       }
                   }
                   
                   catch (Exception ex)
                   {
                       MessageBox.Show(ex.Message);

                   }
                            
               }

               private void tabPage5_Click(object sender, EventArgs e)
               {

               }

               private void addSkillRatingToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   UpdateSkill1 us = new UpdateSkill1();
                   us.Show();
               }

               private void updateExistingSkillRateToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   
               }

               private void rATEEMPLOYEERESPONSIBILITESToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   RateResponsibility us = new RateResponsibility();
                   us.Show();
               }

               private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
               {
                   this.Hide();
                   Form1 fm = new Form1();
                   fm.Show();
               }

               private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
               {

               }

               private void rATEEMPLOYEETASKSToolStripMenuItem_Click(object sender, EventArgs e)
               {

               }

               private void uPDATEONTRAININGSToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   
               }

               private void prToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   New_Project ads = new New_Project();
                   ads.Show();
               }

               private void addNewTaskToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   Assigntask at = new Assigntask();
                   at.Show();
               }

               private void updateProjectToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   UpdateProject up = new UpdateProject();
                   up.Show();
               }

               private void updateTaskToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   UpdateTask ut = new UpdateTask();
                   ut.Show();
               }

               private void viewProjectToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   ViewProject vp = new ViewProject();
                   vp.Show();
               }

               private void viewTaskToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   Assigntask at = new Assigntask();
                   at.Show();
               }

               private void toolStripMenuItem1_Click(object sender, EventArgs e)
               {
                   UpdateTraining ut = new UpdateTraining();
                   ut.Show();
               }

               private void basedOnIERatingToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   UpdateIE uie = new UpdateIE();
                   uie.Show();
               }

               private void vIEWSKILLSETToolStripMenuItem_Click(object sender, EventArgs e)
               {
                   ViewSkillSet vss = new ViewSkillSet();
                   vss.Show();
               }

               private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
               {
                   this.Hide();
                   Form1 fm = new Form1();
                   fm.Show();
               }

               private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
               {
                   this.Hide();
                   Form1 fm = new Form1();
                   fm.Show();
               }

               private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
               {
                   this.Hide();
                   Form1 fm = new Form1();
                   fm.Show();
               }
            }
        }
