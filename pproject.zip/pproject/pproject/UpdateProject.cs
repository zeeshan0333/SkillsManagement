﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace pproject
{
    public partial class UpdateProject : Form
    {
        public UpdateProject()
        {
            InitializeComponent();
            Fillcombo();
        }
       
        
        private void button1_Click(object sender, EventArgs e)

        {
            try
            {
                SqlConnection con;
                SqlDataAdapter da = new SqlDataAdapter();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                da.UpdateCommand = new SqlCommand("UPDATE Project SET  p_title=@p_title,p_manager=@p_manager, p_start=@p_start,p_complete=@p_complete,Status=@Status,p_detail=@p_detail WHERE p_id='" + p_id.SelectedItem.ToString() + "'", con);
                da.UpdateCommand.Parameters.Add("@p_title", SqlDbType.VarChar).Value = p_title.SelectedItem;
                da.UpdateCommand.Parameters.Add("@p_manager", SqlDbType.VarChar).Value = p_manager.Text;
                da.UpdateCommand.Parameters.Add("@p_start", SqlDbType.VarChar).Value = dtp_start.Text;
                da.UpdateCommand.Parameters.Add("@p_complete", SqlDbType.VarChar).Value = dtp_complete.Text;
                da.UpdateCommand.Parameters.Add("@Status", SqlDbType.VarChar).Value = com_status.SelectedItem;
                da.UpdateCommand.Parameters.Add("@p_detail", SqlDbType.VarChar).Value = rich_detail.Text;
                con.Open();
                da.UpdateCommand.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                Assigntask at = new Assigntask();
                at.Show();
                con.Close();
            }
            catch(Exception ec)
            {
                MessageBox.Show(ec.Message);  
            }
        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Project";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int pid = myreader.GetInt32(0);
                    p_id.Items.Add(pid);
                    string sName = myreader.GetString(1);
                    p_title.Items.Add(sName);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
        private void dtp_complete_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
