﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace pproject
{
   
    public partial class Education : Form
    {
        string query;
        Dictionary<string, int> integers = new Dictionary<string, int>();
        public Education()
        {
            InitializeComponent();
            integers.Add("Specialized", 5);
            integers.Add("Minor I", 4);
            integers.Add("Minor II", 3);
            integers.Add("Minor III", 2);
            integers.Add("Minor IV", 1);
            
           Fillcombo();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                query = "insert into Employee_Education values('" + emp_id.Text + "','" + txt_eid.Text + "','" + txt_qualification.SelectedItem.ToString() + "','" + com_gpa.SelectedItem.ToString() + "','" + com_subject.SelectedItem.ToString() + "','" + integers[(string)com_level.SelectedItem] + "')";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Educational Record Inserted Successfully");
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);  
            }
        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Skill";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string id = myreader.GetString(1);
                    com_subject.Items.Add(id);                

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        SqlConnection cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        SqlDataAdapter da = new SqlDataAdapter();
    
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                string query = ("UPDATE Employee_Education SET Highest_Degree= '" + txt_qualification.Text + "',GPA= '" + com_gpa.SelectedItem.ToString() + "',Subjects= '" + com_subject.SelectedItem.ToString()+ "',Educational_Level= '" + integers[(string)com_level.SelectedItem] + "'  WHERE Employee_Id='"+emp_id.Text+"'AND Education_No='" + txt_eid + "'");
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                con.Close();
            }
            catch (Exception ec)
            {
                MessageBox.Show(ec.Message);
            }

        }
       
        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
