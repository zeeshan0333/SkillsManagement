﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class Experience : Form
    {
        string query;
        Dictionary<string, int> integers = new Dictionary<string, int>();
        public Experience()
        {
            InitializeComponent();
            integers.Add("Specialized", 5);
            integers.Add("Minor I", 4);
            integers.Add("Minor II", 3);
            integers.Add("Minor III", 2);
            integers.Add("Minor IV", 1);
           Fillcombo();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Skill";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    string id = myreader.GetString(1);
                    com_field.Items.Add(id);
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
        SqlConnection cs;
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                cs.Open();
                query = "insert into Employee_Experience values('" + textBox1.Text + "','" + txt_exid.Text + "','" + com_field.SelectedItem.ToString() + "','" + integers[(string)com_level.SelectedItem] + "','" + com_duration.SelectedItem.ToString() + "')";
                cmd = new SqlCommand(query, cs);
                cmd.ExecuteNonQuery();
                cs.Close();
                MessageBox.Show("Experience Record Inserted sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
        private void button2_Click(object sender, EventArgs e)
        {
            //da.UpdateCommand = new SqlCommand("UPDATE Employee_Experience SET emp_type=@emp_type, emp_experience=@emp_experience,emp_level=@emp_level, emp_description=@emp_description ", cs);
          //  da.UpdateCommand.Parameters.Add("@emp_type", SqlDbType.VarChar).Value = com_type.SelectedItem;
            //da.UpdateCommand.Parameters.Add("@emp_experience", SqlDbType.VarChar).Value = com_experience.SelectedItem;
            //da.UpdateCommand.Parameters.Add("@emp_level", SqlDbType.Int).Value = integers[(string)com_level.SelectedItem];
            //da.UpdateCommand.Parameters.Add("@emp_description", SqlDbType.VarChar).Value = rich_description.Text;
            //cs.Open();
            //da.UpdateCommand.ExecuteNonQuery();
            //MessageBox.Show("Updated Successfully");
            //cs.Close();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
     
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
