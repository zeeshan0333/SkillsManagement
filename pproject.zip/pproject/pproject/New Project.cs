﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class New_Project : Form
    {
        string qry;
        public New_Project()
        {
            InitializeComponent();
        }

        private void New_Project_Load(object sender, EventArgs e)
        {
            
        }

              
        private void button1_Click_1(object sender, EventArgs e)
        {


            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            qry = "insert into Project(p_id,p_title,p_manager,p_start,p_complete,Status,p_detail) values('" + p_id.Text + "','" + p_title.Text + "','" + p_manager.Text + "','" + dtp_start.Value.ToString("dd/mm/yyyy") + "','" + dtp_complete.Value.ToString("dd/mm/yyyy") + "','"+com_status.SelectedItem.ToString()+"','" + rich_detail.Text + "')";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Project Added Sucessfully");
            Assigntask ads = new Assigntask();
            ads.Show();
        }

        private void p_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
