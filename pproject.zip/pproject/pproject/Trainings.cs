﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class Trainings : Form
    {
        string query;
        
        public Trainings()
        {
            InitializeComponent();
            Fillcombo();
        }
        SqlConnection cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        SqlDataAdapter da = new SqlDataAdapter();
        SqlCommand cmd;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Trainings_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Training";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int id = myreader.GetInt32(0);
                    com_training.Items.Add(id);

                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                this.Hide();
                cs = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                cs.Open();
                query = "insert into Employee_Training values('" + txt_id.Text + "','" + com_training.SelectedItem.ToString() + "', '" + txt_score.Text + "')";
                cmd = new SqlCommand(query, cs);
                cmd.ExecuteNonQuery();
                cs.Close();
                MessageBox.Show("Training Record Inserted sucessfully");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
       
    

        private void button2_Click(object sender, EventArgs e)
        {

            //da.UpdateCommand = new SqlCommand("UPDATE employeetraining SET emp_training=@emp_training, emp_duration=@emp_duration, emp_description=@emp_description WHERE emp_id='" + txt_id.Text + "'", cs);
            //da.UpdateCommand.Parameters.Add("@emp_training", SqlDbType.VarChar).Value = com_training.SelectedItem;
            //da.UpdateCommand.Parameters.Add("@emp_duration", SqlDbType.VarChar).Value = com_training.SelectedItem;
           
            //cs.Open();
            //da.UpdateCommand.ExecuteNonQuery();
           // MessageBox.Show("Updated Successfully");
            //cs.Close();

       }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void com_training_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
