﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

using System.Text.RegularExpressions;
using System.Drawing.Imaging;


using System.Runtime.InteropServices;
using System.Drawing.Text;
using System.Drawing.Drawing2D;
using System.Data.SqlClient;


namespace pproject
{
    public partial class Assigntask : Form
    {
        public Assigntask()
        {
            InitializeComponent();
            Fillcombo();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        string qry;
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            con.Open();
            qry = "insert into Tasks values('" + comboBox1.SelectedItem.ToString() + "','" + com_title.SelectedItem.ToString() + "','" + txt_id.Text + "','" + com_task.SelectedItem.ToString() + "','" + rich_detail.Text + "')";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("Task Added Sucessfully");
            cmd = new SqlCommand("SELECT p_id,p_title,task_id,task_num,Task_Detail FROM Tasks ", con);
            cmd.CommandType = CommandType.Text;
            sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;





        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        private void Assigntask_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            cmd = new SqlCommand("SELECT p_id,p_title,task_id,task_num,Task_Detail FROM Tasks ", con);
            cmd.CommandType = CommandType.Text;
            sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;


        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Project";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int pid = myreader.GetInt32(0);
                    comboBox1.Items.Add(pid);
                    string sName = myreader.GetString(1);
                    com_title.Items.Add(sName);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 0)// created column index (delete button)
                {

                    SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");

                    string query = "Delete  From  Tasks where Task_Id='" + dataGridView1.Rows[e.RowIndex].Cells[2].Value + " '";
                    cmd = new SqlCommand(query, con);
                    con.Open();
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("successfully Deleted", "user information");

                    dataGridView1.Rows.Remove(dataGridView1.Rows[e.RowIndex]);
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }

}

       

        
      
