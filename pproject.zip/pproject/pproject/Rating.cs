﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace pproject

{
    public partial class Rating : Form
    {
        Dictionary<string, int> integers = new Dictionary<string, int>();
         public Rating()
        {
            InitializeComponent();
            integers.Add("Outstanding", 5);
            integers.Add("Excellent", 4);
            integers.Add("Good", 3);
            integers.Add("Satisfactory", 2);
            integers.Add("Acceptable", 1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con;
                SqlDataAdapter da = new SqlDataAdapter();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                da.UpdateCommand = new SqlCommand("UPDATE Employee_Task SET Success_Factor= '" + integers[(string)comboBox1.SelectedItem] + "'  WHERE Employee_Id='" + textBox1.Text + "' AND Skill_Id='" + textBox4.Text + "'", con);
                da.UpdateCommand.ExecuteNonQuery();
                MessageBox.Show("Rated SuccessFully");
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
