﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace pproject
{
    public partial class RateResponsibility : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
        SqlDataAdapter adapter = new SqlDataAdapter();
        SqlCommand SqlCommand;
        public RateResponsibility()
        {
            InitializeComponent();
            Fillcombo();
        }
        void Fillcombo()
        {
            SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = "select * from Employee";
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader myreader;
            try
            {
                con.Open();
                myreader = cmd.ExecuteReader();
                while (myreader.Read())
                {
                    int id = myreader.GetInt32(0);
                    comboBox1.Items.Add(id);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query;
                query = "SELECT * From Job_Description where Employee_Id='" + comboBox1.SelectedItem.ToString() + "'";
                SqlCommand = new SqlCommand(query, con);
                adapter.SelectCommand = new SqlCommand(query, con);
                SqlCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView2.DataSource = dt;
                con.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
              
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
             try
            {
                if (dataGridView2.Columns[e.ColumnIndex].HeaderText == "Rate")
                {
                    RateResponsibility2 export = new RateResponsibility2();
            export.textBox6.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[1].Value.ToString();

            export.textBox1.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[4].Value.ToString();

            export.textBox2.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[5].Value.ToString();

            export.textBox4.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[6].Value.ToString();

            export.textBox3.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[7].Value.ToString();

            export.textBox5.Text = dataGridView2.Rows[dataGridView2.CurrentRow.Index].Cells[8].Value.ToString();


            export.Show();
                }
            }
             catch (Exception ex)
             {
                 MessageBox.Show(ex.Message);
             } 

        }
    }
}
