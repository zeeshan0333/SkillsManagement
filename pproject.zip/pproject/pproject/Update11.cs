﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace pproject
{
    public partial class Update11 : Form
    {
        public Update11()
        {
            InitializeComponent();
            
        }


        private void Update11_Load(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                string query = "Select Rating From Employee Where Employee_Id='" + emp_id.Text + "'";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    p_rating.Text = dr["Rating"].ToString();//Value From Column we want to show on textbox

                }
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
       


        private void button1_Click(object sender, EventArgs e)
        {
            Int32 val1 = Convert.ToInt32(p_rating.Text);
            Int32 val2 = Convert.ToInt32(success_factor.Text);
            Int32 val3 = val1 * val2;
            int result;
            if (val3 <= 9)
            {
                result = val3;
            }
            else
            {
                result = 10;
            }
            label5.Text = result.ToString();
            try
            {
                SqlConnection con;
                SqlDataAdapter da = new SqlDataAdapter();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                da.UpdateCommand = new SqlCommand("Insert into  Employee_Skill  (Employee_Id,Skill_Id,Skill_Rating) values ('" + emp_id.Text + "','"+skill_id.Text+"','"+label5.Text+"')", con);
                da.UpdateCommand.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ec)
            {
                MessageBox.Show(ec.Message);
            }
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void emp_id_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void success_factor_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }        
  }
        
    

