﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class UpdateTask : Form
    {
        public UpdateTask()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con;
                SqlDataAdapter da = new SqlDataAdapter();
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                da.UpdateCommand = new SqlCommand("UPDATE Tasks SET  task_num=@task_num,Task_Detail=@Task_Detail WHERE Task_Id='" + txt_id.Text + "'", con);
                da.UpdateCommand.Parameters.Add("@task_num", SqlDbType.VarChar).Value = com_task.SelectedItem;
                da.UpdateCommand.Parameters.Add("@Task_Detail", SqlDbType.VarChar).Value = rich_detail.Text;
                da.UpdateCommand.ExecuteNonQuery();
                MessageBox.Show("Updated Successfully");
                con.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
