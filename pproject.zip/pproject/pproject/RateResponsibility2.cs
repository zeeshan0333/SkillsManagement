﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace pproject
{
    public partial class RateResponsibility2 : Form
    {
        Dictionary<string, int> integers = new Dictionary<string, int>();
        public RateResponsibility2()
        {
            integers.Add("Outstanding", 4);
            integers.Add("Excellent", 3);
            integers.Add("Good", 2);
            integers.Add("Satisfactory", 1);
            integers.Add("None", 0);
            InitializeComponent();
        }
        SqlConnection con;
        SqlCommand cmd;
        string query;


        private void RateResponsibility2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            try
            {

                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                query = "insert into Performance_Evaluation values('" + textBox6.Text + "','" + textBox7.Text + "','" + integers[(string)comboBox1.SelectedItem] + "','" + integers[(string)comboBox2.SelectedItem] + "','" + integers[(string)comboBox3.SelectedItem] + "','" + integers[(string)comboBox4.SelectedItem] + "','" + integers[(string)comboBox5.SelectedItem] + "','" + integers[(string)comboBox6.SelectedItem] + "')";
                cmd = new SqlCommand(query, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Rate sucessfully");
                
            }
            catch (Exception ec)
            {
                MessageBox.Show(ec.Message);
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
