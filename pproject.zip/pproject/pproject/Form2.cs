﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Windows.Forms.DataVisualization.Charting;

namespace pproject
{
    public partial class Form2 : Form
    {
        string qry;
        String gender;

        public Form2()
        {
            InitializeComponent();

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter sda;
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'projectDataSet.employeeskill' table. You can move, or remove it, as needed.


        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        public bool IsAlpha(String strToCheck)
        {
            Regex objAlphaPattern = new Regex("[^a-zA-Z]");
            return !objAlphaPattern.IsMatch(strToCheck);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (txt_fname.Text != "")
            {
                bool result = IsAlpha(txt_fname.Text);
                if (result == false)
                {
                    MessageBox.Show("Please enter alpahbets value");
                }

            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }


        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void addSkillsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddSkill ads = new AddSkill();
            ads.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void updateSkillsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdateSkill1 ads = new UpdateSkill1();
            ads.Show();
        }

        private void editSkillsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateSkill1 ads = new UpdateSkill1();
            ads.Show();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            UpdateSkill1 ads = new UpdateSkill1();
            ads.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                qry = "insert into Employee(Employee_Id,emp_dep,emp_fname,emp_lname ,emp_gender,emp_dob,emp_address,emp_city,emp_email,emp_contact) values('" + txt_id.Text + "','" + txt_dep.SelectedItem.ToString() + "','" + txt_fname.Text + "','" + txt_lname.Text + "','" + gender + "','" + txt_dob.Value.ToString("dd/mm/yyyy") + "','" + txt_address.Text + "','" + txt_city.SelectedItem.ToString() + "','" + txt_email.Text + "','" + txt_contact.Text + "')";
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Profile Information Inserted Sucessfully");
                txt_id.Text = "";
                txt_dep.SelectedIndex = -1;
                txt_fname.Text = "";
                txt_lname.Text = "";
                txt_dob.Text = "";
                txt_address.Text = "";
                txt_email.Text = "";
                txt_contact.Text = "";
                txt_city.SelectedIndex=-1;
                radioButton1.Checked = false;
                radioButton2.Checked = false;
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void educationToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Education ads = new Education();
            ads.Show();
        }

        private void experienceToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Experience ads = new Experience();
            ads.Show();
        }

        private void trainingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Trainings ads = new Trainings();
            ads.Show();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void skillChartToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void skillsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddSkill ads = new AddSkill();
            ads.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        public bool IsNaturalNumber(String strNumber)
        {
            Regex objNotNaturalPattern = new Regex("[^0-9]");
            Regex objNaturalPattern = new Regex("0*[1-9][0-9]*");
            return !objNotNaturalPattern.IsMatch(strNumber) &&
            objNaturalPattern.IsMatch(strNumber);
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter("select Skill_Id , Skill_Rating from Employee_Skill  where Employee_Id ='" + textBox2.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                chart1.DataSource = dt;
                chart1.ChartAreas["ChartArea1"].AxisX.Title = "Skill Id";
                chart1.ChartAreas["ChartArea1"].AxisY.Title = "Skill Rating";
                chart1.Series["Series1"].XValueMember = "Skill_Id";
                chart1.Series["Series1"].YValueMembers = "Skill_Rating";
                string query = ("SELECT Skill_Name ,Skill_Rating FROM Skill INNER JOIN Employee_Skill ON Skill.Skill_Id=Employee_Skill.Skill_Id WHERE Employee_Id ='" + textBox2.Text + "'");
                cmd = new SqlCommand(query, con);
                sda = new SqlDataAdapter(cmd);
                dt = new DataTable();
                sda.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        /* private void button1_Click(object sender, EventArgs e)
         {
            con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
            string query = ("SELECT * FROM employeeskill WHERE emp_id ='" + textBox1.Text + "'");
            cmd = new SqlCommand(query, con);
            sda = new SqlDataAdapter(cmd);
            DataTable table = new DataTable();
            sda.Fill(table);
             dataGridView2.DataSource = table; 
         }
           */
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txt_dep_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                sda = new SqlDataAdapter("SELECT Employee_Id,Task_Id,p_id,Task_Detail,Success_Factor FROM Employee_Task WHERE Employee_Id='" + textBox1.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridView2.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                con = new SqlConnection(@"Data Source=RUQUIA\SQLEXPRESS;Initial Catalog=Project;Integrated Security=True");
                con.Open();
                qry = "insert into Job_Description values('" + text_id.Text + "','" + txt_jid.Text + "','" + com_designation.SelectedItem.ToString() + "','" + com_r12.SelectedItem.ToString() + "','" + com_r2.SelectedItem.ToString() + "','" + com_r3.SelectedItem.ToString() + "','" + com_r4.SelectedItem.ToString() + "','" + com_r5.SelectedItem.ToString() + "')";
                cmd = new SqlCommand(qry, con);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Designation Information Inserted Sucessfully");
                text_id.Text = "";
                txt_jid.Text = "";
                com_designation.SelectedIndex = -1;
                com_r12.SelectedIndex = -1;
                com_r2.SelectedIndex = -1;
                com_r3.SelectedIndex = -1; 
                com_r3.SelectedIndex = -1;
                com_r5.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void txt_email_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");

            if (txt_email.Text.Length > 0)
            {

                if (!rEMail.IsMatch(txt_email.Text))
                {

                    MessageBox.Show("Use correct format for E-Mail", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    txt_email.SelectAll();    // for select

                    e.Cancel = true;
                }
            }
        }

        private void txt_contact_Validating(object sender, CancelEventArgs e)
        {
            System.Text.RegularExpressions.Regex rPhone = new System.Text.RegularExpressions.Regex(@"^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$|^\d{11}$|^\d{4}-\d{7}$");
            if (txt_contact.Text.Length > 0)
            {

                if (!rPhone.IsMatch(txt_contact.Text))
                {

                    MessageBox.Show("Use correct format for Phone No", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                    txt_contact.SelectAll(); // for select 

                    e.Cancel = true;

                }

            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form1 fm = new Form1();
            fm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_dep.SelectedIndex=-1;
            txt_fname.Text = "";
            txt_lname.Text = "";
            txt_dob.Text= "";
            txt_address.Text = "";
            txt_email.Text = "";
            txt_contact.Text = "";
            txt_city.SelectedText = "";
        }
    }
}
